package com.example.doctracermobile;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PasswordService {
    public static String check(String password){
        String warning = "";
        int len = password.length();

        if ((len < 6)||(len > 32)){
            warning+="Пароль должен содержать от 6 до 32 знаков.";
        }

        String regEx = "[^ \\' \\\" \\{ \\} \\[ \\] \\( \\) \\< \\> . ; \\\\\\ / \\s]" + "{" + Integer.toString(len) + "}";
        Pattern pattern = Pattern.compile(regEx);
        Matcher matcher = pattern.matcher(password);

        if(!matcher.matches()){
            if (warning!= ""){
                warning+="\n";
            }
            warning+="Пароль НЕ МОЖЕТ содержать следующие символы: { } [ ] < > ( ) \u002F \\ \' \" . ; и пробелы.";
        }

        return warning;
    }
}
