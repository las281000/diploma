package com.example.doctracermobile;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.Spinner;

public class Com_Registration extends AppCompatActivity {

    private Spinner edit_com_type;
    private EditText edit_com_type_d;
    private String selected = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_com_registration);
    }

    @Override
    protected void onStart() {
        super.onStart();
        edit_com_type_d = findViewById(R.id.edit_reg_com_type);
        edit_com_type_d.setVisibility(View.INVISIBLE);

        edit_com_type = findViewById(R.id.spin_reg_com_type);

        edit_com_type.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                String [] types = getResources().getStringArray(R.array.com_types);

                selected = types[position];
                System.out.println(selected);

                if (selected.contains("Другое")){
                    System.out.println("OK");
                    edit_com_type_d.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    public void onClick_next_reg(View view){
        Intent head_reg = new Intent (this, Head_Registration.class);
        startActivity(head_reg);
    }
}