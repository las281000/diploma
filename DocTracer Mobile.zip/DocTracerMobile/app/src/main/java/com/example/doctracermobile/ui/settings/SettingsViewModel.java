package com.example.doctracermobile.ui.settings;

import android.arch.lifecycle.ViewModel;

public class SettingsViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}