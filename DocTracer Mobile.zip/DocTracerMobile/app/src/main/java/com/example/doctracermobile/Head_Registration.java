package com.example.doctracermobile;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Head_Registration extends AppCompatActivity {
    EditText passwordEdit;
    EditText passwordEdit_d;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_head_registration);
    }

    @Override
    protected void onStart() {
        super.onStart();

        passwordEdit = findViewById(R.id.edit_reg_head_pass); //первое поле для пароля
        passwordEdit_d = findViewById(R.id.edit_reg_head_pass_d); //подтверждение пароля
    }

    public void onClick_reg_confirm(View view){
        String password = passwordEdit.getText().toString(); // строка из первого поля
        String password_d = passwordEdit_d.getText().toString(); // строка из второго поля

        //System.out.println(password);
        System.out.println(password_d);

        String passSerReply = PasswordService.check(password);

        if (passSerReply!= ""){ //если к строке есть замечания
            passwordEdit_d.setError(passSerReply);
            //ToastCreator.showToast(this, passSerReply);
        }
        else {
            if (!password.equals(password_d)) { //если введены разные строки
                //ToastCreator.showToast(this, "Пароли не совпадают!");
                passwordEdit_d.setError("Пароли не совпадают!");
            }
            else { //если введены одинаковые строки
                Intent confirm = new Intent(this, Confirm_Email.class);
                startActivity(confirm);
            }
        }


    }
}