package com.example.doctracermobile.ui.received;

import android.arch.lifecycle.ViewModel;

public class ReceivedViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}