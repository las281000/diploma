package com.example.doctracermobile;

import android.content.Context;
import android.widget.Toast;

public class ToastCreator {
    public static void showToast (Context context, String text){
        Toast msg = Toast.makeText(context, text, Toast.LENGTH_LONG);
        msg.show();
    }
}
