package com.example.doctracermobile;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Confirm_Email extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_email);
    }

    public void onClick_reg_finish(View view){
        Intent to_start = new Intent(this, Start_Activity.class);
        startActivity(to_start);
    }
}