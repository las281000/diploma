package com.example.doctracermobile;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Start_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
    }

    public void onClick_recover(View view){
        Intent recover = new Intent(this, Account_Recovery.class);
        startActivity(recover);
    }

    public void onClick_signIn(View view){
        //Отправака запроса
        
        Intent signIn = new Intent(this, LK_Profile.class);
        startActivity(signIn);
    }

    public void onClick_reg(View view){
        Intent reg = new Intent(this, Com_Registration.class);
        startActivity(reg);
    }
}