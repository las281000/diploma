package com.example.doctracermobile.ui.staff;

import android.arch.lifecycle.ViewModel;

public class StaffViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}