package com.example.doctracermobile.ui.sent;

import android.arch.lifecycle.ViewModel;

public class SentViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}