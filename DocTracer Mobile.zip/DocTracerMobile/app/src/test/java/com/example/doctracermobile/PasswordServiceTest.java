package com.example.doctracermobile;


import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class PasswordServiceTest {
    public String expectedLen;
    public String expectedSym;

    @Before
    public void setUp(){
        expectedLen = "Пароль должен содержать от 6 до 32 знаков.";
        expectedSym = "Пароль НЕ МОЖЕТ содержать следующие символы: { } [ ] < > ( ) \u002F \\ \' \" . ; и пробелы.";
    }

/////////////////////////////////////////////////////////////////////////////////////////////////////

    @Test
    public void shortPassTest(){
        String password = "Test";
        Assert.assertEquals(expectedLen, PasswordService.check(password));
    }

    @Test
    public void longPassTest(){
        String password = "ThisIsNeededToGetTheWarningFromApplication"; //42 signs
        String expected = "Пароль должен содержать от 6 до 32 знаков.";
        Assert.assertEquals(expectedLen, PasswordService.check(password));
    }

//////////////////////////////////////////////////////////////////////////////////////////////////////

    @Test
    public void RBracketTest(){
        String password = "For(Test)";
        Assert.assertEquals(expectedSym, PasswordService.check(password));
    }

    @Test
    public void SBracketTest(){
        String password = "For[Test]";
        String expected = "Пароль НЕ МОЖЕТ содержать следующие символы: { } \\[ \\] < > ( ) \u002F \\ \' \" . ; и пробелы.";
        Assert.assertEquals(expectedSym, PasswordService.check(password));
    }

    @Test
    public void FBracketTest(){
        String password = "For{Test}";
        Assert.assertEquals(expectedSym, PasswordService.check(password));
    }

    @Test
    public void ABracketTest(){
        String password = "For<Test>";
        Assert.assertEquals(expectedSym, PasswordService.check(password));
    }

    @Test
    public void slashTest(){
        String password = "For/Test";
        Assert.assertEquals(expectedSym, PasswordService.check(password));
    }

    @Test
    public void backSlashTest(){
        String password = "For\\Test";
        Assert.assertEquals(expectedSym, PasswordService.check(password));
    }

    @Test
    public void spaceTest(){
        String password = "For Test";
        Assert.assertEquals(expectedSym, PasswordService.check(password));
    }

    @Test
    public void doubleQuoteTest(){
        String password = "For\"Test";
        Assert.assertEquals(expectedSym, PasswordService.check(password));
    }

    @Test
    public void quoteTest(){
        String password = "For\'Test";
        Assert.assertEquals(expectedSym, PasswordService.check(password));
    }

    @Test
    public void pointTest(){
        String password = "For.Test";
        Assert.assertEquals(expectedSym, PasswordService.check(password));
    }

    @Test
    public void semicolonTest(){
        String password = "For;Test";
        Assert.assertEquals(expectedSym, PasswordService.check(password));
    }

    @Test
    public void correctTest(){
        String password = "CorrectPassword";
        String expected = "";
        Assert.assertEquals(expected, PasswordService.check(password));
    }


}
